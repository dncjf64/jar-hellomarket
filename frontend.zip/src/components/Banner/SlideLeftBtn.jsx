import React from "react";

const SlideLeftBtn = ({ evt }) => {
  return <div className="slide_left" onClick={evt}></div>;
};

export default SlideLeftBtn;
