const categoryList = [
  {
    name: "패션의류",
  },
  {
    name: "패션잡화",
  },
  {
    name: "유아용품",
  },
  {
    name: "가구/생활",
  },
  {
    name: "취미/컬렉션",
  },
  {
    name: "디지털/가전",
  },
  {
    name: "스포츠/레저",
  },
  {
    name: "뷰티/미용",
  },
  {
    name: "반려동식물용품",
  },
  {
    name: "자동차/공구",
  },
  {
    name: "도서/굿즈",
  },
  {
    name: "기타",
  },
  {
    name: "무료나눔",
  },
];

export default categoryList;
